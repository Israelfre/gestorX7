# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains **gestorPRO** — a complete business management system for small and medium businesses (PMEs) in Brazil.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/gestor-pro)
- **Backend**: Express 5 (artifacts/api-server)
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod, drizzle-zod
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## gestorPRO Modules

1. **Dashboard** (`/`) — Balance, receivables, clients, today's tasks, alerts
2. **Clientes** (`/clientes`) — Client CRUD, debtor tracking, client history
3. **Financeiro** (`/financeiro`) — Income/expense tracking, financial summary
4. **Agenda** (`/agenda`) — Task management with overdue highlighting
5. **Estoque** (`/estoque`) — Inventory with low-stock alerts
6. **Orcamentos** (`/orcamentos`) — Quote management with "convert to sale" feature

## Alert System

Automatic visual alerts for:
- Clients who are debtors
- Overdue tasks
- Low stock items (below minQuantity threshold)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/gestor-pro run dev` — run frontend locally

## Routes

- Frontend: `/` (served by gestor-pro artifact)
- API: `/api` (served by api-server artifact)

## Auth & Multi-Tenant System

- **Session-based auth**: express-session + connect-pg-simple (cookie: `gx7.sid`, 7 days, stored in DB `sessions` table)
- **Roles**: `admin` (full access + admin panel) and `client` (tenant-isolated access)
- **Admin login**: admin@gestorx7.com / admin123
- **Admin panel**: `/admin` — create/manage client accounts with plans (free/trial/monthly/yearly), view plan status (ativo/vencendo/expirado), toggle active/inactive
- **Plan enforcement**: middleware blocks expired plans (except free/admin)
- **Tenant isolation**: all data tables have `tenant_id` column; all routes filter by session tenantId

## Database Tables

- `tenants` — One per client company
- `users` — Auth users (admin + clients), linked to tenant
- `sessions` — Express session storage (auto-managed by connect-pg-simple)
- `clients` — Client records with debtor tracking
- `transactions` — Income/expense financial movements
- `tasks` — Scheduled tasks/services
- `inventory` — Product stock management
- `quotes` — Budget/quote management
- All tables have `tenant_id` for data isolation

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
