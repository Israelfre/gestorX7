import { Router } from "express";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { requireAuth } from "../middleware/auth";

const router = Router();

router.post("/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "E-mail e senha são obrigatórios" });
      return;
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase().trim())).limit(1);
    if (!user) {
      res.status(401).json({ error: "E-mail ou senha incorretos" });
      return;
    }

    if (!user.isActive) {
      res.status(403).json({ error: "Conta desativada. Contate o administrador." });
      return;
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: "E-mail ou senha incorretos" });
      return;
    }

    req.session.userId = user.id;
    req.session.tenantId = user.tenantId;
    req.session.role = user.role as "admin" | "client";
    req.session.name = user.name;
    req.session.email = user.email;
    req.session.plan = user.plan;
    req.session.planExpiresAt = user.planExpiresAt ? user.planExpiresAt.toISOString() : null;

    // Salva explicitamente antes de responder para garantir persistência no DB
    req.session.save((err) => {
      if (err) {
        console.error("Erro ao salvar sessão:", err);
        res.status(500).json({ error: "Erro ao criar sessão" });
        return;
      }
      res.json({
        sessionId: req.sessionID,
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        plan: user.plan,
        planExpiresAt: user.planExpiresAt,
        tenantId: user.tenantId,
      });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("gx7.sid");
    res.json({ ok: true });
  });
});

router.get("/auth/me", requireAuth, async (req, res) => {
  const s = req.session;
  const planExpired =
    s.role !== "admin" &&
    s.plan !== "free" &&
    s.planExpiresAt != null &&
    new Date(s.planExpiresAt) < new Date();

  res.json({
    id: s.userId,
    name: s.name,
    email: s.email,
    role: s.role,
    plan: s.plan,
    planExpiresAt: s.planExpiresAt,
    tenantId: s.tenantId,
    planExpired,
  });
});

export default router;
